


<html >

<head>



<title>How to Upload PHOTO</title>


</head>
<body bgcolor="#F0F4F1">
<body topmargin="0" leftmargin="0" rightmargin="0" marginheight="0" marginwidth="0">

<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">



            <tr>

             

              <td><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Guidelines for scanning the Photograph , Signature & Draft </strong></td>

            </tr>

            <tr>

              <td colspan="4" height="1" bgcolor="#E9FAFE"></td>

            </tr>

            <tr>

              <td colspan="4">&nbsp;</td>

            </tr>

          </table>

            <table width="600" border="0" align="center" cellpadding="2" cellspacing="2">

           <!--  <tr>

                <td  class="tablecontent1"><span class="personaldetails">Guidelines for Scribe:</span> </td>

              </tr>-->

               <tr>

                <td  class="tablecontent2">Before applying online a candidate will be required to have a scanned (digital) image of his/her photograph , signature and scanned image of the Draft  as per the specifications given below.</td>

              </tr>

              <tr>

                <td align="center" valign="top" ><table width="95%" border="0" cellspacing="1" cellpadding="0">		    

					<!-- <tr>

                      <td align="left" colspan="2" valign="top" class="tablecontent1" >The candidate will have to arrange his/her own scribe-</td>                      

                    </tr> -->

                    <tr>

                      <td width="14" align="center" valign="top" class="tablecontent1" ><span class="personaldetails"><b>(i)</b></span></td>

                      <td width="545" valign="top" class="tablecontent1"><div align="justify"><span class="text1"><b>Photograph Image: </b></span></div></td>

                    </tr>

					<tr>

                      <td width="14" align="center" valign="top" class="tablecontent1" ></td>

                      <td width="545" valign="top" class="tablecontent1" align="left">Photograph must be a recent passport style colour picture.</td>

                    </tr>

					<tr>

                      <td width="14" align="center" valign="top" class="tablecontent1" ></td>

                      <td width="545" valign="top" class="tablecontent1"  align="left">Make sure that the picture is in colour, taken against a light-coloured, preferably white, background.</td>

                    </tr>

					<tr>

                      <td width="14" align="center" valign="top" class="tablecontent1" ></td>

                      <td width="545" valign="top" class="tablecontent1"  align="left">Ensure that the size of the scanned image is not more than 25KB. If the size of the file is more than 25KB, then adjust the settings of the scanner such as the DPI resolution, no. of colours etc., during the process of scanning.</td>

                    </tr>

					 <tr>

                      <td width="14" align="center" valign="top" class="tablecontent2" ><span class="personaldetails"><b>(ii)</b></span></td>

                      <td width="545" valign="top" class="tablecontent2"><div align="justify"><span class="text1"><b>Signature Image :</b></span></div></td>

                    </tr>

					<tr>

                      <td width="14" align="center" valign="top" class="tablecontent2" ></td>

                      <td width="545" valign="top" class="tablecontent2" align="left">The applicant has to sign on white paper with Black Ink pen.</td>

                    </tr>

					<tr>

                      <td width="14" align="center" valign="top" class="tablecontent2" ></td>

                      <td width="545" valign="top" class="tablecontent2" align="left">The signature must be signed only by the applicant and not by any other person.</td>

                    </tr>

					<tr>

                      <td width="14" align="center" valign="top" class="tablecontent2" ></td>

                      <td width="545" valign="top" class="tablecontent2" align="left">The signature will be used to put on the Hall Ticket and wherever necessary.</td>

                    </tr>

					<tr>

                      <td width="14" align="center" valign="top" class="tablecontent2" ></td>

                      <td width="545" valign="top" class="tablecontent2" align="left">If the Applicant's signature on the answer script, at the time of the examination, does not match the signature on the Hall Ticket, the applicant will be disqualified. </td>

                    </tr>

					<tr>

                      <td width="14" align="center" valign="top" class="tablecontent2" ></td>

                      <td width="545" valign="top" class="tablecontent2" align="left">Dimensions 140 x 60 pixels (preferred)</td>

                    </tr>

					

					<tr>

                      <td width="14" align="center" valign="top" class="tablecontent2" ></td>

                      <td width="545" valign="top" class="tablecontent2" align="left"><b>If the file size and format are not as prescribed, an error message will be displayed.</b></td>

                    </tr>

					<tr>

                      <td width="14" align="center" valign="top" class="tablecontent2" ></td>

                      <td width="545" valign="top" class="tablecontent2" align="left">While filling in the Online Application Form the candidate will be provided with a link to upload his photograph ,signature and Draft. </td>

                    </tr>

					<tr>

                      <td width="14" align="center" valign="top" class="tablecontent2" ></td>

                      <td width="545" valign="top" class="tablecontent2" align="left"><b>Procedure for Uploading the Photograph , Signature and Draft</b></td>

                    </tr>

					<tr>

                      <td width="14" align="center" valign="top" class="tablecontent2" ></td>

                      <td width="545" valign="top" class="tablecontent2" align="left">(i) There will be a link for uploading Photograph , Signature and Draft </td>

                    </tr>

					<tr>

                      <td width="14" align="center" valign="top" class="tablecontent2" ></td>

                      <td width="545" valign="top" class="tablecontent2" align="left">(ii) Click on the respective link "Upload Photograph / Signature/ Draft"</td>

                    </tr>

					<tr>

                      <td width="14" align="center" valign="top" class="tablecontent2" ></td>

                      <td width="545" valign="top" class="tablecontent2" align="left">(iii) Browse and Select the location where the Scanned Photograph / Signature  file has been saved.</td>

                    </tr>

					<tr>

                      <td width="14" align="center" valign="top" class="tablecontent2" ></td>

                      <td width="545" valign="top" class="tablecontent2" align="left">(iv) Select the file by clicking on it</td>

                    </tr>

					<tr>

                      <td width="14" align="center" valign="top" class="tablecontent2" ></td>

                      <td width="545" valign="top" class="tablecontent2" align="left">(v) Click the 'Upload' button </td>

                    </tr>

					<tr>

                      <td width="14" align="center" valign="top" class="tablecontent1" ></td>

                      <td width="545" valign="top" class="tablecontent1" align="left"></td>

                    </tr>

					<tr>

                      <td width="14" align="center" valign="top" class="tablecontent1" ></td>

                      <td width="545" valign="top" class="tablecontent1" align="left"><b>Your Online Application will not be registered unless you upload your photograph , signature and Draft as specified.</b></td>

                    </tr>

					<tr>

                      <td width="14" align="center" valign="top" class="tablecontent1" ></td>

                      <td width="545" valign="top" class="tablecontent1" align="left"><b>Note:</b></td>

                    </tr>

					<tr>

                      <td width="14" align="center" valign="top" class="tablecontent1" ></td>

                      <td width="545" valign="top" class="tablecontent1" align="left">1. In case the face in the photograph or signature is unclear the candidate's application may be rejected.</td>

                    </tr>

					<tr>

                      <td width="14" align="center" valign="top" class="tablecontent1" ></td>

                      <td width="545" valign="top" class="tablecontent1" align="left">2. After registering online candidates are advised to take a printout of their system generated online application forms and need not be sent to us. </td>

                    </tr>

					
					
					</table></td>

              </tr>



            </table></td>

        </tr>

        <tr>

        <td height="5" valign="top"></td>

      </tr>

      <tr><td><table width="100%" border="0" cellpadding="0" cellspacing="0"  bgcolor="#0499c2">

          <tr>

            <td width="390" class="#409702">&nbsp;</td>

            <td width="416" class="#409702">&nbsp;</td>

  </tr>

        </table></td></tr>

    </table></td>

  </tr>

</table>

<table align=center>

<tr>

     <td> <a href='index.php'>Home </a>  &nbsp; &nbsp; </td>

              <td><a href='register.php'>Register </a>  </td>
</tr>

</table>

</body>

</html>
