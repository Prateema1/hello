<html >

<head>
<body bgcolor="#F0F4F1">


<title>Online Application :: How to Apply </title>




		

        <tr>

          <td height="300" valign="top"><table width="750" border="0" align="center" cellpadding="2" cellspacing="0">

            <tr>

              <td colspan="4" height="15"></td>

            </tr>

            <tr>

            

              <b><td>HOW TO APPLY <br><br></td></b>

     
            </tr>

          

          </table>

            <table width="780" border="0" align="center" cellpadding="2" cellspacing="2">

			  <tr>

			     <td width="24" class="tablecontent2"></td>

			     <td valign="top" class="tablecontent2"><strong>Eligible candidates are required to apply only 'ONLINE' through our website   between 24.06.2011 and 16.07.2011 <strong> and no other means/ mode of application will be acceptable.</strong></p>		         </td>

	          </tr>

			   <tr>

			     <td align="center" class="tablecontent1"><strong>(i)</strong></td>

			     <td valign="top" class="tablecontent1"><strong>Candidates are required to have a valid personal e-mail ID. It should be kept active for the duration of this recruitment project. We may send call letters for written test, interview etc. through this registered e-mail ID.</strong></td>

		      </tr>

			   <tr>

			     <td align="center" class="tablecontent2"><strong>(ii)</strong></td>

			     <td valign="top" class="tablecontent2">In case a candidate does not have a valid personal e-mail ID, he/she should create his/her new e-mail ID before applying online.</td>

		      </tr>

			   <tr>

			     <td align="center" class="tablecontent1"><strong>(iii)</strong></td>

			     <td valign="top" class="tablecontent1"> Carefully fill in the necessary details in the Online Application Form at the appropriate places and submit the same Online.</td>

		      </tr>

			   <tr>

			     <td align="center" class="tablecontent2"><strong>(iv)</strong></td>

			     <td valign="top" class="tablecontent2"> The name of the candidate or his/ her father/ husband etc should be spelt correctly in the application as it appears in the certificates/ mark sheets. Any change/ alteration found may disqualify the candidature :</td>

		      </tr>

			  <tr>

			     <td align="center" class="tablecontent1"></td>

			     <td valign="top" class="tablecontent1"><strong><b>You should note / remember your system generated ROLL NUMBER for future reference and use.</b><strong></td>

		      </tr>

			  

			   <tr>

			     <td align="center" class="tablecontent1"><strong>(v)</strong></td>

			     <td valign="top" class="tablecontent1">An application once made will not be allowed to be withdrawn.</td>

		      </tr>

			   

			   <tr>

			     <td align="center" class="tablecontent2"><strong>(vi)</strong></td>

			     <td valign="top" class="tablecontent2">After filling in the details on the application form candidates are required to take a printout of the system generated application form immediately. Candidates should keep the printout of the application form and that need not to be sent to NIC.</td>

		      </tr>

			   <tr>

			     <td align="center" class="tablecontent1"><strong>(vii)</strong></td>

			     <td valign="top" class="tablecontent1">There is no provision to modify the submitted online application. Candidates are requested to make sure  to fill in correct the details in the online application, if any. </td>

		      </tr>

	<tr>

			     <td align="center" class="tablecontent1"><strong>(viii)</strong></td>

			     <td valign="top" class="tablecontent1"><strong><b>Once you have submitted your application successfully, You will get the intimation through EMAIL and SMS.</b></strong> </td>

		      </tr>



			

			

    </table></td>

  </tr>

</table>

<table align=center>

<tr>
 <td> <a href='index.php'>Home </a>  &nbsp; &nbsp;  </td>

              <td>          <a href='register.php'>REGISTER  </a> </td>

</tr>

</table>

</body>
